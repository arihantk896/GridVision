"""
app.py
======
Streamlit dashboard — Electricity Distribution Network Analyzer
IEEE 33-Bus Radial Distribution System

Run:
    streamlit run app.py

Layout
------
  ┌──────────────────────────────────────────────────────┐
  │  Sidebar: DG configuration controls                  │
  ├──────────────────────────────────────────────────────┤
  │  Header metrics (KPI cards)                          │
  ├────────────────────┬─────────────────────────────────┤
  │  Network Topology  │  Voltage Profile                │
  ├────────────────────┴─────────────────────────────────┤
  │  Branch Losses (bar)  |  Loss Breakdown (pie)        │
  ├──────────────────────────────────────────────────────┤
  │  Tabbed raw data tables (Bus / Branch / DG / Solver) │
  └──────────────────────────────────────────────────────┘
"""

import streamlit as st
import pandas as pd
import numpy as np

from analytics import NetworkAnalyzer
from plots import (
    plot_network_graph,
    plot_voltage_profile,
    plot_branch_losses,
    plot_voltage_comparison,
    plot_loss_breakdown,
)

# ──────────────────────────────────────────────────────────────────────────────
# Page config (must be first Streamlit call)
# ──────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Electricity Distribution Network Analyzer",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────────────────────────────────────
# Custom CSS — minimal dark-accent card styling
# ──────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* ---------- KPI card ---------- */
  .kpi-card {
      background: #1e293b;
      border-radius: 12px;
      padding: 16px 20px;
      text-align: center;
      color: #f1f5f9;
      box-shadow: 0 2px 8px rgba(0,0,0,.25);
  }
  .kpi-value  { font-size: 1.7rem; font-weight: 700; color: #38bdf8; }
  .kpi-label  { font-size: 0.78rem; color: #94a3b8; margin-top: 4px; }
  .kpi-sub    { font-size: 0.72rem; color: #64748b; }

  /* ---------- violation badges ---------- */
  .badge-ok    { background:#16a34a; color:white; padding:2px 8px; border-radius:999px; font-size:.75rem; }
  .badge-warn  { background:#dc2626; color:white; padding:2px 8px; border-radius:999px; font-size:.75rem; }
  .badge-over  { background:#ea580c; color:white; padding:2px 8px; border-radius:999px; font-size:.75rem; }

  /* ---------- section header ---------- */
  .section-header {
      font-size:1.05rem; font-weight:600; color:#334155;
      border-left:4px solid #38bdf8; padding-left:10px; margin:18px 0 10px;
  }
</style>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────────
# Initialise the analyzer (cached so state survives reruns)
# ──────────────────────────────────────────────────────────────────────────────
@st.cache_resource
def get_base_analyzer() -> NetworkAnalyzer:
    """Return a fresh base-case analyzer (no DG).  Cached across reruns."""
    return NetworkAnalyzer()


@st.cache_resource
def get_analyzer() -> NetworkAnalyzer:
    """Return the working analyzer shared across UI interactions."""
    return NetworkAnalyzer()


base_an = get_base_analyzer()
an      = get_analyzer()


# ──────────────────────────────────────────────────────────────────────────────
# Sidebar — DG Controls
# ──────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("⚡ DG Configuration")
    st.caption("Add rooftop solar PV units to any bus and watch the network respond in real time.")

    st.divider()

    # ── Add DG section ──────────────────────────────────────────────────────
    st.subheader("➕ Add / Update Solar DG")

    dg_bus = st.selectbox(
        "Select Bus",
        options=list(range(2, 34)),   # buses 2–33 (1 is slack)
        index=14,                      # default bus 15
        help="Bus 1 is the substation slack bus and cannot host DG.",
    )
    dg_p = st.slider(
        "Active Power P (kW)",
        min_value=0,
        max_value=500,
        value=100,
        step=10,
        help="Solar PV active power injection (0 = disabled).",
    )
    dg_q = st.slider(
        "Reactive Power Q (kVAR)",
        min_value=-200,
        max_value=200,
        value=0,
        step=10,
        help="Positive Q = reactive generation (capacitive); negative Q = absorption.",
    )
    dg_label = st.text_input("Label", value="Solar PV")

    col_add, col_rem = st.columns(2)
    with col_add:
        if st.button("✅ Apply", use_container_width=True, type="primary"):
            an.add_dg(int(dg_bus), float(dg_p), float(dg_q), dg_label)
            st.success(f"DG applied at Bus {dg_bus}")

    with col_rem:
        if st.button("❌ Remove", use_container_width=True):
            an.remove_dg(int(dg_bus))
            st.info(f"DG removed from Bus {dg_bus}")

    st.divider()

    # ── Active DG table ─────────────────────────────────────────────────────
    st.subheader("📋 Active DG Units")
    dg_df = an.dg_summary()
    if dg_df.empty:
        st.caption("No DG units active.")
    else:
        st.dataframe(dg_df, hide_index=True, use_container_width=True)

    if st.button("🗑️ Clear All DG", use_container_width=True):
        an.clear_all_dg()
        st.success("All DG units cleared.")

    st.divider()

    # ── Voltage limits ───────────────────────────────────────────────────────
    st.subheader("⚙️ Voltage Limits")
    v_min = st.number_input("V_min (p.u.)", min_value=0.80, max_value=0.99, value=0.95, step=0.01)
    v_max = st.number_input("V_max (p.u.)", min_value=1.01, max_value=1.20, value=1.05, step=0.01)
    an.v_min = v_min
    an.v_max = v_max


# ──────────────────────────────────────────────────────────────────────────────
# Main content
# ──────────────────────────────────────────────────────────────────────────────
st.title("⚡ Electricity Distribution Network Analyzer")
st.caption("IEEE 33-Bus Radial Distribution System  ·  Backward/Forward Sweep (BFS) Power Flow")
st.divider()

# Solve and collect results
metrics   = an.summary_metrics()
bus_df    = an.bus_dataframe()
branch_df = an.branch_dataframe()
graph     = an.build_graph()

base_bus_df = base_an.bus_dataframe()

# ──────────────────────────────────────────────────────────────────────────────
# KPI header row
# ──────────────────────────────────────────────────────────────────────────────

def kpi(value, label, sub=""):
    return f"""
    <div class="kpi-card">
      <div class="kpi-value">{value}</div>
      <div class="kpi-label">{label}</div>
      <div class="kpi-sub">{sub}</div>
    </div>"""


# Violation badges
n_under = metrics["n_under_violations"]
n_over  = metrics["n_over_violations"]
v_badge = ""
if n_under == 0 and n_over == 0:
    v_badge = '<span class="badge-ok">✓ No Violations</span>'
else:
    parts = []
    if n_under > 0:
        parts.append(f'<span class="badge-warn">↓ {n_under} Under</span>')
    if n_over > 0:
        parts.append(f'<span class="badge-over">↑ {n_over} Over</span>')
    v_badge = "  ".join(parts)

c1, c2, c3, c4, c5, c6 = st.columns(6)
with c1:
    st.markdown(kpi(f"{metrics['total_load_kw']:,.1f} kW", "Total Load", f"{metrics['total_load_kvar']:,.1f} kVAR"), unsafe_allow_html=True)
with c2:
    st.markdown(kpi(f"{metrics['total_gen_kw']:,.1f} kW", "Total DG Generation", f"{metrics['total_gen_kvar']:,.1f} kVAR"), unsafe_allow_html=True)
with c3:
    st.markdown(kpi(f"{metrics['total_ploss_kw']:,.2f} kW", "Active Losses", f"({metrics['loss_pct']:.2f}% of load)"), unsafe_allow_html=True)
with c4:
    st.markdown(kpi(f"{metrics['total_qloss_kvar']:,.2f} kVAR", "Reactive Losses", ""), unsafe_allow_html=True)
with c5:
    st.markdown(kpi(
        f"{metrics['min_voltage_pu']:.5f} p.u.",
        "Minimum Bus Voltage",
        f"Bus {metrics['min_voltage_bus']}"
    ), unsafe_allow_html=True)
with c6:
    conv_badge = "✅ Converged" if metrics["converged"] else "❌ Not Converged"
    st.markdown(kpi(conv_badge, "Solver Status", f"{metrics['iterations']} iterations"), unsafe_allow_html=True)

st.markdown(f"**Voltage Violations:** {v_badge}", unsafe_allow_html=True)
st.divider()

# ──────────────────────────────────────────────────────────────────────────────
# Network Topology + Voltage Profile (side by side)
# ──────────────────────────────────────────────────────────────────────────────
col_topo, col_vprof = st.columns([1.2, 1], gap="medium")

with col_topo:
    st.markdown('<div class="section-header">🗺️ Network Topology</div>', unsafe_allow_html=True)
    st.caption("Node colour → voltage level (🟢 normal · 🔴 under-voltage · 🟠 over-voltage) · ⭐ DG unit · 🟦 Substation")
    fig_graph = plot_network_graph(graph)
    st.plotly_chart(fig_graph, use_container_width=True)

with col_vprof:
    st.markdown('<div class="section-header">📊 Voltage Profile</div>', unsafe_allow_html=True)
    has_dg = not an.dg_summary().empty

    if has_dg:
        tab_cmp, tab_bar = st.tabs(["📈 Comparison (Base vs DG)", "📊 Current Profile"])
        with tab_cmp:
            fig_cmp = plot_voltage_comparison(base_bus_df, bus_df, v_min, v_max)
            st.plotly_chart(fig_cmp, use_container_width=True)
        with tab_bar:
            fig_vbar = plot_voltage_profile(bus_df, v_min, v_max)
            st.plotly_chart(fig_vbar, use_container_width=True)
    else:
        fig_vbar = plot_voltage_profile(bus_df, v_min, v_max)
        st.plotly_chart(fig_vbar, use_container_width=True)

st.divider()

# ──────────────────────────────────────────────────────────────────────────────
# Branch Losses + Pie
# ──────────────────────────────────────────────────────────────────────────────
col_bar, col_pie = st.columns([1.6, 1], gap="medium")

with col_bar:
    st.markdown('<div class="section-header">🔋 Branch Power Losses</div>', unsafe_allow_html=True)
    fig_loss = plot_branch_losses(branch_df)
    st.plotly_chart(fig_loss, use_container_width=True)

with col_pie:
    st.markdown('<div class="section-header">🍩 Loss Distribution</div>', unsafe_allow_html=True)
    fig_pie = plot_loss_breakdown(branch_df)
    st.plotly_chart(fig_pie, use_container_width=True)

st.divider()

# ──────────────────────────────────────────────────────────────────────────────
# Data tables (tabbed)
# ──────────────────────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">📋 Detailed Data Tables</div>', unsafe_allow_html=True)

tab_bus, tab_branch, tab_dg, tab_solver = st.tabs([
    "🚌 Bus Data",
    "🔗 Branch Data",
    "☀️ DG Units",
    "🔢 Solver Info",
])

with tab_bus:
    # Colour-code violation rows
    def highlight_violation(row):
        if row["Violation"] == "under":
            return ["background-color: #fee2e2"] * len(row)
        elif row["Violation"] == "over":
            return ["background-color: #fff7ed"] * len(row)
        return [""] * len(row)

    st.dataframe(
        bus_df.style.apply(highlight_violation, axis=1),
        use_container_width=True,
        height=500,
    )
    st.caption("🔴 Red rows = under-voltage  |  🟠 Orange rows = over-voltage")

with tab_branch:
    st.dataframe(
        branch_df.style.background_gradient(
            subset=["P Loss (kW)", "Q Loss (kVAR)"],
            cmap="YlOrRd"
        ),
        use_container_width=True,
        height=500,
    )
    st.caption("Darker red = higher loss branch")

with tab_dg:
    if dg_df.empty:
        st.info("No DG units currently active.  Use the sidebar to add solar PV injections.")
    else:
        st.dataframe(dg_df, use_container_width=True, hide_index=True)
        total_dg_p = dg_df["P (kW)"].sum()
        total_dg_q = dg_df["Q (kVAR)"].sum()
        st.metric("Total DG Active Power",   f"{total_dg_p:.1f} kW")
        st.metric("Total DG Reactive Power", f"{total_dg_q:.1f} kVAR")

with tab_solver:
    st.subheader("BFS Solver Configuration & Results")
    solver_info = {
        "Algorithm"             : "Backward / Forward Sweep (BFS)",
        "System"                : "IEEE 33-Bus Radial Distribution",
        "Base Voltage (kV)"     : an.base_kv,
        "Base MVA"              : an.base_mva,
        "Base Impedance (Ω)"    : round(an.solver.z_base, 4),
        "Convergence Tolerance" : an.solver.tol,
        "Max Iterations"        : an.solver.max_iter,
        "Iterations Used"       : metrics["iterations"],
        "Converged"             : metrics["converged"],
        "Under-Voltage Limit"   : f"{v_min} p.u.",
        "Over-Voltage Limit"    : f"{v_max} p.u.",
    }
    st.table(pd.DataFrame.from_dict(solver_info, orient="index", columns=["Value"]))

    st.subheader("BFS Algorithm — Equations Reference")
    st.latex(r"""
    \textbf{Backward Sweep (leaf} \to \textbf{root):}
    \qquad I_{km} = \left(\frac{S_m}{V_m}\right)^*
    = \left(\frac{P_m - jQ_m}{V_m^*}\right)
    """)
    st.latex(r"""
    \textbf{Forward Sweep (root} \to \textbf{leaf):}
    \qquad V_m = V_k - I_{km} \cdot Z_{km}
    \quad \text{where } Z_{km} = R_{km} + jX_{km}
    """)
    st.latex(r"""
    \textbf{Branch Losses:}
    \quad P_{loss} = |I_{km}|^2 R_{km},
    \qquad Q_{loss} = |I_{km}|^2 X_{km}
    """)
    st.latex(r"""
    \textbf{Convergence:}
    \quad \max_{\text{bus}}\left|V^{(k+1)} - V^{(k)}\right| < \varepsilon
    \quad (\varepsilon = 10^{-5}\ \text{p.u.})
    """)

# ──────────────────────────────────────────────────────────────────────────────
# Footer
# ──────────────────────────────────────────────────────────────────────────────
st.divider()
st.caption(
    "**Electricity Distribution Network Analyzer** · "
    "IEEE 33-Bus Radial Test System · "
    "BFS Power Flow · "
    "Built with Streamlit & Plotly"
)

