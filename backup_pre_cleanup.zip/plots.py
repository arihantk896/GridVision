"""
plots.py
========
Plotly & NetworkX visualisation helpers for the Streamlit dashboard.

All functions return Plotly Figure objects (or NetworkX position dicts)
so they can be displayed with st.plotly_chart().
"""

import math
import numpy as np
import pandas as pd
import networkx as nx
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots


# ---------------------------------------------------------------------------
# Colour helpers
# ---------------------------------------------------------------------------

_VMIN_LIMIT = 0.95
_VMAX_LIMIT = 1.05


def _vmag_color(vmag: float) -> str:
    """Map a voltage magnitude to a red/yellow/green colour string."""
    if vmag < _VMIN_LIMIT:
        return "#EF4444"    # red  — under-voltage
    elif vmag > _VMAX_LIMIT:
        return "#F97316"    # orange — over-voltage
    else:
        # Interpolate green→yellow based on how far from 1.0
        deviation = abs(vmag - 1.0) / (_VMAX_LIMIT - 1.0)
        deviation = min(deviation, 1.0)
        return f"rgba({int(34 + 221*deviation)}, {int(197 - 47*deviation)}, 94, 1)"


def _node_colorscale(vmag_values):
    """Return a list of colours for each bus node."""
    return [_vmag_color(v) for v in vmag_values]


# ---------------------------------------------------------------------------
# Network topology graph
# ---------------------------------------------------------------------------

def _radial_layout(G: nx.Graph, root: int) -> dict:
    """
    Compute a hierarchical (top-down tree) layout for a radial network.
    Uses NetworkX's Graphviz-style shell-by-depth positions.
    """
    # BFS layers from root
    layers = dict(nx.bfs_successors(G, root))
    pos    = {}
    depth  = {root: 0}
    queue  = [root]
    level_nodes: dict = {}

    while queue:
        node = queue.pop(0)
        d    = depth[node]
        level_nodes.setdefault(d, []).append(node)
        for child in layers.get(node, []):
            depth[child] = d + 1
            queue.append(child)

    max_depth = max(depth.values()) if depth else 1

    for d, nodes in level_nodes.items():
        n = len(nodes)
        for i, node in enumerate(nodes):
            x = (i - (n - 1) / 2.0) * max(1.0, 10.0 / n)
            y = -d * 2.5
            pos[node] = (x, y)

    return pos


def plot_network_graph(G: nx.Graph, highlight_dg: bool = True) -> go.Figure:
    """
    Render the distribution network as an interactive Plotly scatter graph.

    Nodes are coloured by voltage magnitude (green=normal, red=violation).
    DG buses are marked with a star overlay.
    Edge widths are proportional to branch active losses.
    """
    root   = min(G.nodes())               # bus 1 is always the root
    pos    = _radial_layout(G, root)

    # ---------- edge traces ----------
    edge_traces = []
    max_loss = max((G.edges[e]["p_loss_kw"] for e in G.edges()), default=1.0)
    max_loss = max(max_loss, 1e-6)

    for u, v, data in G.edges(data=True):
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        loss    = data["p_loss_kw"]
        width   = 1.5 + 5.0 * (loss / max_loss)
        color   = f"rgba(100,116,139,0.55)"

        edge_traces.append(
            go.Scatter(
                x=[x0, x1, None],
                y=[y0, y1, None],
                mode="lines",
                line=dict(width=width, color=color),
                hoverinfo="text",
                hovertext=(
                    f"Branch {u}→{v}<br>"
                    f"P Loss: {loss:.3f} kW<br>"
                    f"R: {data['r_ohm']:.4f} Ω  X: {data['x_ohm']:.4f} Ω"
                ),
                showlegend=False,
            )
        )

    # ---------- bus nodes ----------
    vmag_list  = [G.nodes[n]["vmag"]     for n in G.nodes()]
    node_colors = _node_colorscale(vmag_list)

    node_x   = [pos[n][0] for n in G.nodes()]
    node_y   = [pos[n][1] for n in G.nodes()]
    node_ids = list(G.nodes())

    hover_texts = []
    for n in G.nodes():
        d = G.nodes[n]
        text = (
            f"<b>Bus {n}</b><br>"
            f"V: {d['vmag']:.5f} p.u. | {d['vang']:.3f}°<br>"
            f"P Load: {d['p_load_kw']:.1f} kW"
        )
        if d["has_dg"]:
            text += "<br>⚡ DG unit present"
        if d["is_slack"]:
            text += "<br>🔌 Slack / Substation"
        hover_texts.append(text)

    node_trace = go.Scatter(
        x=node_x,
        y=node_y,
        mode="markers+text",
        text=[str(n) for n in node_ids],
        textposition="top center",
        textfont=dict(size=9, color="#1e293b"),
        marker=dict(
            size=18,
            color=node_colors,
            line=dict(width=1.5, color="#334155"),
        ),
        hovertext=hover_texts,
        hoverinfo="text",
        showlegend=False,
    )

    # ---------- DG overlay markers ----------
    dg_nodes  = [n for n in G.nodes() if G.nodes[n]["has_dg"]]
    dg_x      = [pos[n][0] for n in dg_nodes]
    dg_y      = [pos[n][1] for n in dg_nodes]
    dg_trace  = go.Scatter(
        x=dg_x, y=dg_y,
        mode="markers",
        marker=dict(symbol="star", size=24, color="#FBBF24",
                    line=dict(width=1.5, color="#92400E")),
        name="DG Unit",
        hoverinfo="skip",
        showlegend=(len(dg_nodes) > 0),
    )

    # Slack node overlay
    slack_trace = go.Scatter(
        x=[pos[root][0]], y=[pos[root][1]],
        mode="markers",
        marker=dict(symbol="square", size=22, color="#6366F1",
                    line=dict(width=2, color="#3730A3")),
        name="Slack Bus (Substation)",
        hoverinfo="skip",
        showlegend=True,
    )

    fig = go.Figure(data=edge_traces + [node_trace, dg_trace, slack_trace])
    fig.update_layout(
        title="Network Topology — IEEE 33-Bus Radial Feeder",
        title_font_size=16,
        paper_bgcolor="#F8FAFC",
        plot_bgcolor="#F1F5F9",
        showlegend=True,
        legend=dict(x=0.01, y=0.99, bgcolor="rgba(255,255,255,0.8)"),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        margin=dict(l=10, r=10, t=50, b=10),
        height=520,
    )
    return fig


# ---------------------------------------------------------------------------
# Voltage profile bar chart
# ---------------------------------------------------------------------------

def plot_voltage_profile(bus_df, v_min: float = 0.95, v_max: float = 1.05) -> go.Figure:
    """
    Horizontal bar chart of bus voltage magnitudes (p.u.) with
    limit lines and colour-coded violation zones.
    """
    df     = bus_df.copy().sort_values("Bus ID")
    vmag   = df["V (p.u.)"].values
    bus_id = df["Bus ID"].values
    colors = [_vmag_color(v) for v in vmag]

    fig = go.Figure()

    # Voltage bars
    fig.add_trace(go.Bar(
        y=[f"Bus {b}" for b in bus_id],
        x=vmag,
        orientation="h",
        marker_color=colors,
        text=[f"{v:.4f}" for v in vmag],
        textposition="outside",
        hovertemplate="Bus %{y}<br>V = %{x:.5f} p.u.<extra></extra>",
        name="Voltage (p.u.)",
    ))

    # Limit lines
    fig.add_vline(x=v_min, line_dash="dash", line_color="#DC2626",
                  annotation_text=f"V_min={v_min}", annotation_position="bottom right")
    fig.add_vline(x=v_max, line_dash="dash", line_color="#EA580C",
                  annotation_text=f"V_max={v_max}", annotation_position="top right")
    fig.add_vline(x=1.0, line_dash="dot", line_color="#475569",
                  annotation_text="1.0 p.u.", annotation_position="top right")

    fig.update_layout(
        title="Voltage Profile — All Buses",
        xaxis_title="Voltage Magnitude (p.u.)",
        yaxis_title="Bus",
        paper_bgcolor="#F8FAFC",
        plot_bgcolor="#F1F5F9",
        height=max(400, 18 * len(bus_id)),
        margin=dict(l=80, r=80, t=50, b=40),
        xaxis=dict(range=[min(0.90, vmag.min() - 0.01), max(1.06, vmag.max() + 0.01)]),
    )
    return fig


# ---------------------------------------------------------------------------
# Branch losses bar chart
# ---------------------------------------------------------------------------

def plot_branch_losses(branch_df) -> go.Figure:
    """
    Grouped bar chart of active (kW) and reactive (kVAR) losses per branch.
    """
    df    = branch_df.copy()
    label = [f"{int(r['From Bus'])}→{int(r['To Bus'])}" for _, r in df.iterrows()]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name="Active Loss (kW)",
        x=label,
        y=df["P Loss (kW)"],
        marker_color="#3B82F6",
        hovertemplate="Branch %{x}<br>P Loss: %{y:.4f} kW<extra></extra>",
    ))
    fig.add_trace(go.Bar(
        name="Reactive Loss (kVAR)",
        x=label,
        y=df["Q Loss (kVAR)"],
        marker_color="#8B5CF6",
        hovertemplate="Branch %{x}<br>Q Loss: %{y:.4f} kVAR<extra></extra>",
    ))

    fig.update_layout(
        title="Branch Power Losses",
        xaxis_title="Branch (From → To)",
        yaxis_title="Loss (kW / kVAR)",
        barmode="group",
        paper_bgcolor="#F8FAFC",
        plot_bgcolor="#F1F5F9",
        legend=dict(x=0.75, y=0.99),
        xaxis_tickangle=-60,
        height=420,
        margin=dict(l=60, r=20, t=50, b=120),
    )
    return fig


# ---------------------------------------------------------------------------
# Voltage comparison line chart (base vs DG scenario)
# ---------------------------------------------------------------------------

def plot_voltage_comparison(
    bus_df_base,
    bus_df_dg,
    v_min: float = 0.95,
    v_max: float = 1.05,
) -> go.Figure:
    """
    Line chart overlaying base-case and DG-scenario voltage profiles for
    quick visual comparison of voltage improvement.
    """
    fig = go.Figure()

    for df, name, color, dash in [
        (bus_df_base, "Base Case",   "#64748B", "solid"),
        (bus_df_dg,   "With DG",     "#22C55E", "solid"),
    ]:
        df_s = df.sort_values("Bus ID")
        fig.add_trace(go.Scatter(
            x=df_s["Bus ID"],
            y=df_s["V (p.u.)"],
            mode="lines+markers",
            name=name,
            line=dict(color=color, dash=dash, width=2.5),
            marker=dict(size=6),
            hovertemplate="Bus %{x}<br>V = %{y:.5f} p.u.<extra></extra>",
        ))

    fig.add_hline(y=v_min, line_dash="dash", line_color="#DC2626",
                  annotation_text=f"V_min={v_min}")
    fig.add_hline(y=v_max, line_dash="dash", line_color="#EA580C",
                  annotation_text=f"V_max={v_max}")

    fig.update_layout(
        title="Voltage Profile Comparison: Base Case vs. DG Scenario",
        xaxis_title="Bus ID",
        yaxis_title="Voltage Magnitude (p.u.)",
        paper_bgcolor="#F8FAFC",
        plot_bgcolor="#F1F5F9",
        legend=dict(x=0.75, y=0.05),
        height=400,
        margin=dict(l=60, r=20, t=50, b=50),
    )
    return fig


# ---------------------------------------------------------------------------
# Losses pie chart
# ---------------------------------------------------------------------------

def plot_loss_breakdown(branch_df) -> go.Figure:
    """Pie chart of active losses by branch (top 10 shown, rest aggregated)."""
    df = branch_df.copy()
    df["Branch Label"] = df.apply(
        lambda r: f"{int(r['From Bus'])}→{int(r['To Bus'])}", axis=1
    )
    df_sorted = df.sort_values("P Loss (kW)", ascending=False)

    TOP_N = 10
    if len(df_sorted) > TOP_N:
        top    = df_sorted.iloc[:TOP_N]
        rest   = df_sorted.iloc[TOP_N:]
        rest_row = pd.DataFrame([{
            "Branch Label": "Other branches",
            "P Loss (kW)": rest["P Loss (kW)"].sum(),
        }])
        df_plot = pd.concat([top[["Branch Label", "P Loss (kW)"]], rest_row], ignore_index=True)
    else:
        df_plot = df_sorted[["Branch Label", "P Loss (kW)"]]

    fig = go.Figure(go.Pie(
        labels=df_plot["Branch Label"],
        values=df_plot["P Loss (kW)"],
        hole=0.45,
        textinfo="label+percent",
        marker=dict(line=dict(color="white", width=1.5)),
    ))
    fig.update_layout(
        title="Active Loss Distribution by Branch (Top 10)",
        paper_bgcolor="#F8FAFC",
        height=400,
        margin=dict(l=20, r=20, t=50, b=20),
    )
    return fig

